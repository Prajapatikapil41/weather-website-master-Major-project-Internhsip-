
<?php
  require "./partials/dbBlogs.php";

  $fetch = true;
  $sql = "SELECT * FROM  allblogs ORDER BY `allblogs`.`time` DESC;";
  $result = mysqli_query($conn,$sql);
  
  $aff = mysqli_affected_rows($conn);
  if ($aff<1) {
      $fetch = false;
  }
  else{
      $fetch = true;
  }
  
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Weather BLOG</title>    
    <meta name='viewport' content='width=device-width, initial-scale=1.0'> 
    <?php 
      require "./partials/links.php";    
    ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="http://localhost/weather-website-master/application/blogger/index.css">
    <link rel="stylesheet" href="http://localhost/weather-website-master/application/blogger/static/css/profileIndexCommonCard.css">
    
  </head>

<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
  <div class="logo">
           Weather App
        </div>
    <ul class="nav navbar-nav">
    <li><a href="http://localhost/weather-website-master/index.html">Home</a></li>
            <li><a href="http://localhost/weather-website-master/application/aboutus/aboutus.html">About Us</a></li>
            <li><a href="application/blogger/index.php">Blogs</a></li>
            <li><a href="http://localhost/weather-website-master/application/contactus/contactus.php">Contact Us</a></li>
            <li><a href="http://localhost/weather-website-master/application/Map/mapindex.html" button type="Map" name="Map">Map</button></a></li>
    </ul>
  </div>
</nav>
  <?php 
    require "./partials/sideBar.php";
  ?>

  <section class="home-section">
    
    <?php 
    
      if(isset($_SESSION) and isset($_SESSION['username'])){
        $currentUser = $_SESSION['username'];

        echo "<h3 class='text'> Welcome, $currentUser</h3>";
      }
      else{
        echo "<div class='text'>Blogs</div>";
      }

    ?>

    <div id= "blogs" class="my-1 mb-6">


      <?php
          if($fetch){

              while($data = mysqli_fetch_object($result)){

              
                
                $blogSno = $data->{'blog_sno'};
                $username = $data->{'username'};
                $email = $data->{'email'};
                $blogTitle = $data->{'blog_title'};
                $blogSubtitle = $data->{'blog_subtitle'};

                $blogContent = $data->{'blog_content'};
                $blogLen = strlen($blogContent);
                $mainContent = substr($blogContent,0,200);
                $readMore = substr($blogContent,200,$blogLen);
                $blogTime = $data->{'time'};
                $newDate = date("j-F Y", strtotime($blogTime));
                $newTime = date("l, g:i a", strtotime($blogTime));

                echo
                "<div class='card'>
                    <div class='image-data'>
                    <div class='background-image'></div>
                    <div class='publication-details'>
                        <a href='#' class='author'><i class='fas fas-user'></i>$username</a>
                        <span class='date'><i class='fas fa-calender-alt'></i>$email</span>
                        <span class='date'><i class='fas fa-calender-alt'></i>$newDate</span>
                        <span class='date'><i class='fas fa-calender-alt'></i>$newTime</span>
                    </div>
                    </div>
                    <div class='post-data'>
                    <h1 class='title'>$blogTitle</h1>
                    <h2 class='subtitle'>$blogSubtitle</h2>
                    <p class='description'>
                        $mainContent<span class='dots'>.........</span><span class='more-text'>$readMore</span>                        
                    </p>
                    
                    <div class='cta'>  
                        <button class='read-more-btn' onclick='readMore(this)' >Read more</button>  
                    </div>
                    </div>
                </div>";

            }
          }
        ?>
      
      
    </div>

      

  </section>


</body>
</html>
