<?php

$boolAdminLoggedIn = false;
session_start();
if(isset($_SESSION) and isset($_SESSION["AdminUsername"])){  
    $boolAdminLoggedIn = true;   
}
else{
    $boolAdminLoggedIn = false;
    header("location: http://localhost/weather-website-master/application/blogger/admin/adminindex.php");
}
require '../partials/dbConnection.php';
$get_query = "select * from contactus";
$qry = mysqli_query($conn, $get_query);
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="http://localhost/weather-website-master/application/blogger/admin/bootstrap.min.css">
    <title>Contact Us</title>
    <?php  require '../partials/links.php'?>
</head>
<body class="bg-dark">
    <?php require '../partials/adminNavbar.php';  ?>
    <div class ="container">
        <div class="row mt-5">
            <div class="col">
                <div class="card mt-5"> 
                    <div class="card-header">
                        <h2 class="display-6 text-center"> Contact Us Form </h2>
                    </div>
                    <div class="card-body"> 
                    <table class="table table-bordered text-center"> 
                        <thead>
                      <tr class="bg-dark text-white">
                       <td> Id  </td>
                       <td> Name  </td>
                       <td> Email  </td>
                       <td> Message  </td>
                       <td> Create Date  </td>
                       <td> Edit  </td>
                       <td> Delete  </td>
                      </tr>
                        </thead>
                      <tr> 
                      <?php while ($fetch = mysqli_fetch_array($qry)){    ?>
                        <td><?php  echo $fetch['id'] ;?></td>
                        <td><?php  echo $fetch['name'] ;?></td>
                        <td><?php  echo $fetch['email'] ;?></td>
                        <td><?php  echo $fetch['message'] ;?></td>
                        <td><?php  echo $fetch['createdat'] ;?></td>
                        <td> <a href="contactusedit.php?id=<?= $fetch['id']; ?>" class="btn btn-primary">Edit</a></td>
                        <td> <a href="#" class="btn btn-danger">Delete</a></td>
                      </tr>
                        <?php  }  ?>
                    
                    </table>
                    </div>
                </div>
            </div>
        </div>    
    </div>
</body>
</html>
