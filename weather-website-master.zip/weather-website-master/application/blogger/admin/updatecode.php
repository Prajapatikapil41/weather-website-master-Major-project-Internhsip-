<?php
$conn = mysqli_connect("localhost", "root","");
$db = mysqli_select_db($conn, 'blog_website');   
if(isset($_POST['Edit']))
{
    
    $edit_id = $_POST['edit_id'];
    $name = $_POST['name'];
    $email =  $_POST['email'];
    $message = $_POST['message']; 
    
    $query = "UPDATE contactus SET name='$name', email='$email', message='$message' WHERE id='$edit_id'";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
       echo '<script> alert("Data Updated"); </script>';
        header("Location: contactusedit.php");
       Exit(0);
    }
    else
    {
        echo '<script> alert("Data Not Updated"); </script>';
    }
}
?>