<?php
session_start();
require '../partials/dbConnection.php';     
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://localhost/weather-website-master/application/contactus/bootstrap.min.css" rel="stylesheet">
  <link href="http://localhost/weather-website-master/application/contactus/contactusstyle.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" /> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" />
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Lexend&family=Recursive:wght@300&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Arvo&display=swap" rel="stylesheet">
  <link href="https://kit-pro.fontawesome.com/releases/v5.15.3/css/pro.min.css" rel="stylesheet">
    <link rel="stylesheet" href="http://localhost/weather-website-master/application/blogger/admin/bootstrap.min.css">
    <title>Contact Us Edit</title>
    <?php  require '../partials/links.php'?>
</head>
<body class="bg-dark">
<section class="contactUs-section-page">
<?php
if (isset($_POST['submit'])) {			
    $name = $_POST['name'];
    $email =  $_POST['email'];
    $message = $_POST['message'];
    $contact_query = "INSERT INTO contactus(name, email, message) VALUES('$name', '$email', '$message')";
    $inquery = mysqli_query($conn,$contact_query);
    if($inquery){
        ?>
        <script>
            alert("Your query has Submited ")
        </script>
        <?php
    }else{
        ?>
        <script>
            alert("Your query has not Submited")
        </script>
        <?php
    }
}

?>
   <div class ="container mt-4">
        <div class="row mt-5">
            <div class="col">
                <div class="card mt-5"> 
                    <div class="card-header">
                        <h2 class="display-6 text-center"> Contact Us Edit Form <a href="http://localhost/weather-website-master/application/blogger/admin/adminQueries.php" class="btn btn-danger float-end">Back</a></h2>
                    </div>
                    <div class="card-body"> 
                    <?php
                    if(isset($_GET['id']))
                    {
                        $edit_id = mysqli_real_escape_string($conn, $_GET['id'] );
                        $query = "SELECT * FROM contactus WHERE id='$edit_id'";
                        $query_run = mysqli_query($conn , $query);
                        if(mysqli_num_rows($query_run) > 0)
                        {
                           $contactus = mysqli_fetch_array($query_run);
                           ?>
                <form class="form" action="updatecode.php" method="POST">
                <input type="hidden" name="edit_id" value="<?= $edit_id ?>"> 
                            <div class="form-group py-2">
                            <div class="form-group py-2">
                                <label class="pb-1" for="name"><span><i style="color: red;" class="fas fa-user" aria-hidden="true" ></i></span> Name </label>
                                <input type="text" class="form-control  " name="name" id="name" aria-describedby="helpId"
                                    value="<?=$contactus['name'];?>" placeholder="ENTER YOUR NAME">
                                    
                            </div>

                            <div class="form-group py-2">
                                <label class="pb-1" for="email"><span><i style="color: red;" class="fas fa-envelope" aria-hidden="true" ></i></span> Email</label>
                                <input type="text" class="form-control " name="email" id="email"
                                value="<?=$contactus['email'];?>"  aria-describedby="helpId" placeholder="ENTER YOUR EMAIL">
                            </div>

                            <div class="form-group py-2">
                                <label class="pb-1" for="message"><span><i style="color: red;" class="fas fa-comment-alt" aria-hidden="true"></i></span> Message</label>
                                <input type="text" class="form-control "   id="mssg" name="message" rows="4" value="<?=$contactus['message'];?>"
                                 placeholder="ENTER YOUR MESSAGE">
                            </div>
                            <center>
                                <button type="Edit" name="Edit" class="btn btn-warning my-3">Edit</button>
                            </center>
                </form>
                        <?php
                        }
                        else
                        {
                            echo "<h4>No such Id found</h4>";
                        }

                    }
                    
                    ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
                </div>
            </div>
        </div>    
    </div>

</section>
</body>
</html>
