<?php
session_start();
session_unset();
session_destroy();

header("Location: http://localhost/weather-website-master/application/blogger/signIn/signIn.php");

?>